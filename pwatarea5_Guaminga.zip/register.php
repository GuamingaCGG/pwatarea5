<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';

if (isLoggedIn()) { header("Location: dashboard.php"); exit(); }

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($password !== $confirm) {
        $error = "Las contraseñas no coinciden.";
    } elseif (strlen($password) < 6) {
        $error = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = "Ese correo ya está registrado.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, role_id) VALUES (?, ?, ?, 3)");
            $stmt->bind_param("sss", $username, $email, $hash);
            if ($stmt->execute()) {
                $success = "¡Cuenta creada! Ya puedes iniciar sesión.";
            } else {
                $error = "Error al crear la cuenta.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registro - Biblioteca Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body { background: linear-gradient(135deg,#1a1a2e,#16213e,#0f3460); min-height:100vh; display:flex; align-items:center; font-family:'Lato',sans-serif; }
  .card { background:rgba(255,255,255,0.05); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,0.1); border-radius:16px; padding:2.5rem; color:white; }
  h1 { font-family:'Playfair Display',serif; color:#e8d5b0; }
  .form-control { background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.2); color:white; border-radius:8px; }
  .form-control:focus { background:rgba(255,255,255,0.15); color:white; border-color:#e8d5b0; box-shadow:none; }
  .form-control::placeholder { color:rgba(255,255,255,0.4); }
  .btn-register { background:#e8d5b0; color:#1a1a2e; font-weight:700; border:none; border-radius:8px; padding:10px; }
  .btn-register:hover { background:#d4b896; color:#1a1a2e; }
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card shadow-lg">
        <div class="text-center mb-4">
          <i class="bi bi-person-plus" style="font-size:3rem;color:#e8d5b0;"></i>
          <h1 class="mt-2">Crear Cuenta</h1>
          <p class="text-white-50">Se registrará como Lector</p>
        </div>

        <?php if ($error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
          <div class="alert alert-success"><?= htmlspecialchars($success) ?> <a href="index.php">Iniciar sesión</a></div>
        <?php endif; ?>

        <form method="POST">
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-person"></i> Nombre de usuario</label>
            <input type="text" name="username" class="form-control" placeholder="Tu nombre" required>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-envelope"></i> Correo electrónico</label>
            <input type="email" name="email" class="form-control" placeholder="correo@ejemplo.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-lock"></i> Contraseña</label>
            <input type="password" name="password" class="form-control" placeholder="Mínimo 6 caracteres" required>
          </div>
          <div class="mb-4">
            <label class="form-label"><i class="bi bi-lock-fill"></i> Confirmar contraseña</label>
            <input type="password" name="confirm" class="form-control" placeholder="Repite tu contraseña" required>
          </div>
          <button type="submit" class="btn btn-register w-100 mb-3">
            <i class="bi bi-check-circle"></i> Registrarse
          </button>
        </form>
        <p class="text-center">
          <a href="index.php" class="text-warning">← Volver al inicio de sesión</a>
        </p>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
