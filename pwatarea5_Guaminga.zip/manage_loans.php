<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();
if (getRole() !== 'Librarian' && getRole() !== 'Administrator') {
    header("Location: dashboard.php"); exit();
}

$msg = '';

// Marcar como devuelto
if (isset($_GET['return'])) {
    $id = intval($_GET['return']);
    $t = $conn->query("SELECT * FROM transactions WHERE id=$id")->fetch_assoc();
    if ($t && !$t['returned']) {
        $conn->query("UPDATE transactions SET returned=1, date_of_return=NOW() WHERE id=$id");
        $conn->query("UPDATE books SET available=available+1 WHERE id={$t['book_id']}");
        $msg = '<div class="alert alert-success"> Libro marcado como devuelto.</div>';
    }
}

$loans = $conn->query("
    SELECT t.*, b.title, u.username, u.email
    FROM transactions t
    JOIN books b ON t.book_id = b.id
    JOIN users u ON t.user_id = u.id
    WHERE t.returned = 0
    ORDER BY t.date_of_return ASC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestionar Préstamos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
  h4{font-family:'Playfair Display',serif;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="dashboard.php" class="nav-link d-inline"><i class="bi bi-house me-1"></i>Inicio</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h4 class="mb-1"> Gestionar Préstamos Activos</h4>
  <p class="text-muted mb-4">Libros actualmente en préstamo</p>
  <?= $msg ?>

  <?php if ($loans->num_rows === 0): ?>
    <div class="alert alert-info"><i class="bi bi-check2-circle"></i> No hay préstamos activos en este momento.</div>
  <?php else: ?>
  <div class="card shadow-sm">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
          <tr><th>Libro</th><th>Usuario</th><th>Prestado</th><th>Vence</th><th>Estado</th><th>Acción</th></tr>
        </thead>
        <tbody>
          <?php while ($l = $loans->fetch_assoc()): ?>
          <?php $overdue = $l['date_of_return'] < date('Y-m-d'); ?>
          <tr class="<?= $overdue ? 'table-warning' : '' ?>">
            <td><strong><?= htmlspecialchars($l['title']) ?></strong></td>
            <td>
              <?= htmlspecialchars($l['username']) ?><br>
              <small class="text-muted"><?= htmlspecialchars($l['email']) ?></small>
            </td>
            <td><?= $l['date_of_issue'] ?></td>
            <td><?= $l['date_of_return'] ?></td>
            <td>
              <?php if ($overdue): ?>
                <span class="badge bg-danger"> Vencido</span>
              <?php else: ?>
                <span class="badge bg-primary"> Activo</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="?return=<?= $l['id'] ?>" class="btn btn-sm btn-success"
                 onclick="return confirm('¿Marcar como devuelto?')">
                <i class="bi bi-arrow-return-left"></i> Registrar devolución
              </a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
