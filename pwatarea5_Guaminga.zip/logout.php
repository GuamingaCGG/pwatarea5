<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
session_destroy();
header("Location: index.php");
exit();
?>
