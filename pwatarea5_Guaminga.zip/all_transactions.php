<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();
if (getRole() !== 'Administrator' && getRole() !== 'Librarian') {
    header("Location: dashboard.php"); exit();
}

$transactions = $conn->query("
    SELECT t.*, b.title, b.author, u.username
    FROM transactions t
    JOIN books b ON t.book_id = b.id
    JOIN users u ON t.user_id = u.id
    ORDER BY t.id DESC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Todas las Transacciones</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
  h4{font-family:'Playfair Display',serif;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="dashboard.php" class="nav-link d-inline"><i class="bi bi-house me-1"></i>Inicio</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h4 class="mb-1"> Todas las Transacciones</h4>
  <p class="text-muted mb-4">Historial completo de préstamos</p>

  <div class="card shadow-sm">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
          <tr><th>#</th><th>Usuario</th><th>Libro</th><th>Fecha Préstamo</th><th>Fecha Devolución</th><th>Estado</th></tr>
        </thead>
        <tbody>
          <?php if ($transactions->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No hay transacciones registradas.</td></tr>
          <?php endif; ?>
          <?php while ($t = $transactions->fetch_assoc()): ?>
          <?php $overdue = !$t['returned'] && $t['date_of_return'] < date('Y-m-d'); ?>
          <tr class="<?= $overdue ? 'table-warning' : '' ?>">
            <td><?= $t['id'] ?></td>
            <td><i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($t['username']) ?></td>
            <td><strong><?= htmlspecialchars($t['title']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($t['author']) ?></small></td>
            <td><?= $t['date_of_issue'] ?></td>
            <td><?= $t['date_of_return'] ?? '-' ?></td>
            <td>
              <?php if ($t['returned']): ?>
                <span class="badge bg-success"> Devuelto</span>
              <?php elseif ($overdue): ?>
                <span class="badge bg-danger"> Vencido</span>
              <?php else: ?>
                <span class="badge bg-primary"> Activo</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
