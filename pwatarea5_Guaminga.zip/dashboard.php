<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

$role = getRole();

// Estadísticas generales
$totalBooks = $conn->query("SELECT COUNT(*) as c FROM books")->fetch_assoc()['c'];
$totalUsers = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$activeLoans = $conn->query("SELECT COUNT(*) as c FROM transactions WHERE returned = 0")->fetch_assoc()['c'];
$myLoans = $conn->query("SELECT COUNT(*) as c FROM transactions WHERE user_id = {$_SESSION['user_id']} AND returned = 0")->fetch_assoc()['c'];

// Libros recientes
$recentBooks = $conn->query("SELECT * FROM books ORDER BY id DESC LIMIT 6");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Biblioteca Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body { background:#f8f5f0; font-family:'Lato',sans-serif; }
  .navbar { background: linear-gradient(90deg,#1a1a2e,#0f3460); }
  .navbar-brand { font-family:'Playfair Display',serif; color:#e8d5b0 !important; font-size:1.4rem; }
  .nav-link { color:rgba(255,255,255,0.8) !important; }
  .nav-link:hover { color:#e8d5b0 !important; }
  .sidebar { background:#1a1a2e; min-height: calc(100vh - 56px); padding:1.5rem 0; }
  .sidebar a { color:rgba(255,255,255,0.7); display:block; padding:10px 20px; text-decoration:none; border-radius:8px; margin:2px 10px; transition:all .2s; }
  .sidebar a:hover, .sidebar a.active { background:rgba(232,213,176,0.15); color:#e8d5b0; }
  .sidebar .section-title { color:rgba(255,255,255,0.3); font-size:0.7rem; text-transform:uppercase; letter-spacing:2px; padding:10px 20px 4px; }
  .stat-card { border:none; border-radius:12px; padding:1.5rem; color:white; }
  .card { border:none; border-radius:12px; }
  .badge-role { font-size:0.75rem; padding:4px 10px; border-radius:20px; }
</style>
</head>
<body>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto d-flex align-items-center gap-3">
      <span class="text-white-50 d-none d-md-block">
        <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($_SESSION['username']) ?>
        <?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
          $badges = ['Administrator'=>'bg-danger','Librarian'=>'bg-warning text-dark','Reader'=>'bg-success'];
          $roleEs = ['Administrator'=>'Administrador','Librarian'=>'Bibliotecario','Reader'=>'Lector'];
          $b = $badges[$role] ?? 'bg-secondary';
          echo "<span class='badge $b ms-1'>".(($roleEs[$role]) ?? $role)."</span>";
        ?>
      </span>
      <a href="logout.php" class="btn btn-sm btn-outline-light"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container-fluid">
<div class="row">
  <!-- SIDEBAR -->
  <div class="col-md-2 sidebar d-none d-md-block">
    <div class="section-title">General</div>
    <a href="dashboard.php" class="active"><i class="bi bi-house me-2"></i>Inicio</a>
    <a href="catalog.php"><i class="bi bi-journals me-2"></i>Catálogo</a>

    <?php if ($role === 'Reader' || $role === 'Librarian' || $role === 'Administrator'): ?>
    <div class="section-title mt-3">Mi Cuenta</div>
    <a href="my_loans.php"><i class="bi bi-bookmark-check me-2"></i>Mis Préstamos</a>
    <?php endif; ?>

    <?php if ($role === 'Librarian' || $role === 'Administrator'): ?>
    <div class="section-title mt-3">Bibliotecario</div>
    <a href="manage_books.php"><i class="bi bi-plus-circle me-2"></i>Gestionar Libros</a>
    <a href="manage_loans.php"><i class="bi bi-arrow-left-right me-2"></i>Gestionar Préstamos</a>
    <?php endif; ?>

    <?php if ($role === 'Administrator'): ?>
    <div class="section-title mt-3">Administrador</div>
    <a href="manage_users.php"><i class="bi bi-people me-2"></i>Gestionar Usuarios</a>
    <a href="all_transactions.php"><i class="bi bi-list-ul me-2"></i>Todas las Trans.</a>
    <?php endif; ?>
  </div>

  <!-- MAIN CONTENT -->
  <div class="col-md-10 p-4">
    <h4 class="mb-1" style="font-family:'Playfair Display',serif;">Bienvenido, <?= htmlspecialchars($_SESSION['username']) ?> 👋</h4>
    <p class="text-muted mb-4">Panel de control de la Biblioteca Online</p>

    <!-- Stats -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card" style="background:linear-gradient(135deg,#667eea,#764ba2);">
          <div style="font-size:2rem;font-weight:700;"><?= $totalBooks ?></div>
          <div class="opacity-75"><i class="bi bi-book me-1"></i>Total Libros</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card" style="background:linear-gradient(135deg,#f093fb,#f5576c);">
          <div style="font-size:2rem;font-weight:700;"><?= $activeLoans ?></div>
          <div class="opacity-75"><i class="bi bi-bookmark me-1"></i>Préstamos Activos</div>
        </div>
      </div>
      <?php if ($role === 'Administrator'): ?>
      <div class="col-6 col-md-3">
        <div class="stat-card" style="background:linear-gradient(135deg,#4facfe,#00f2fe);">
          <div style="font-size:2rem;font-weight:700;"><?= $totalUsers ?></div>
          <div class="opacity-75"><i class="bi bi-people me-1"></i>Usuarios</div>
        </div>
      </div>
      <?php endif; ?>
      <div class="col-6 col-md-3">
        <div class="stat-card" style="background:linear-gradient(135deg,#43e97b,#38f9d7);">
          <div style="font-size:2rem;font-weight:700;"><?= $myLoans ?></div>
          <div class="opacity-75"><i class="bi bi-bookmark-check me-1"></i>Mis Préstamos</div>
        </div>
      </div>
    </div>

    <!-- Libros recientes -->
    <h5 class="mb-3" style="font-family:'Playfair Display',serif;">📚 Libros Disponibles</h5>
    <div class="row g-3">
      <?php while ($book = $recentBooks->fetch_assoc()): ?>
      <div class="col-md-4">
        <div class="card shadow-sm p-3">
          <div class="d-flex align-items-start gap-3">
            <div style="background:linear-gradient(135deg,#1a1a2e,#0f3460);color:#e8d5b0;padding:12px;border-radius:8px;font-size:1.5rem;">
              <i class="bi bi-book"></i>
            </div>
            <div>
              <strong><?= htmlspecialchars($book['title']) ?></strong>
              <div class="text-muted small"><?= htmlspecialchars($book['author']) ?> · <?= $book['year'] ?></div>
              <div class="mt-1">
                <span class="badge <?= $book['available'] > 0 ? 'bg-success' : 'bg-danger' ?>">
                  <?= $book['available'] > 0 ? "✅ {$book['available']} disponibles" : "❌ Sin disponibilidad" ?>
                </span>
              </div>
            </div>
          </div>
          <?php if ($role === 'Reader' && $book['available'] > 0): ?>
          <a href="request_book.php?id=<?= $book['id'] ?>" class="btn btn-sm btn-outline-primary mt-2">
            <i class="bi bi-hand-index"></i> Solicitar préstamo
          </a>
          <?php endif; ?>
        </div>
      </div>
      <?php endwhile; ?>
    </div>

    <div class="mt-3">
      <a href="catalog.php" class="btn btn-primary"><i class="bi bi-journals me-1"></i>Ver catálogo completo</a>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
