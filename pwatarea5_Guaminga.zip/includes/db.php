<?php
define('DB_HOST', 'sql303.infinityfree.com');
define('DB_USER', 'if0_41883543');
define('DB_PASS', 'gcchristR17');
define('DB_NAME', 'if0_41883543_biblioteca');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("<div style='font-family:sans-serif;padding:20px;background:#fee;border:1px solid red;'>
        <h3> Error de conexión a la base de datos</h3>
        <p>Error: " . $conn->connect_error . "</p>
    </div>");
}

$conn->set_charset("utf8");
?>
