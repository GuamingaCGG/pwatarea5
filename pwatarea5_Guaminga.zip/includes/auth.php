<?php
// InfinityFree requiere session_start() al inicio, no dentro de funciones
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getRole() {
    return $_SESSION['role'] ?? '';
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

function requireRole($role) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
    if (($_SESSION['role'] ?? '') !== $role) {
        header("Location: dashboard.php");
        exit();
    }
}
