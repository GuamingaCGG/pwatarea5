<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

$role = getRole();
$search = trim($_GET['search'] ?? '');
$genre = $_GET['genre'] ?? '';

$where = "WHERE 1=1";
$params = [];
$types = '';
if ($search) { $where .= " AND (title LIKE ? OR author LIKE ?)"; $s = "%$search%"; $params[] = $s; $params[] = $s; $types .= 'ss'; }
if ($genre) { $where .= " AND genre = ?"; $params[] = $genre; $types .= 's'; }

if ($params) {
    $stmt = $conn->prepare("SELECT * FROM books $where ORDER BY title");
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $books = $stmt->get_result();
} else {
    $books = $conn->query("SELECT * FROM books ORDER BY title");
}

$genres = $conn->query("SELECT DISTINCT genre FROM books WHERE genre IS NOT NULL ORDER BY genre");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Catálogo - Biblioteca Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
  .book-icon{background:linear-gradient(135deg,#1a1a2e,#0f3460);color:#e8d5b0;padding:15px;border-radius:10px;font-size:2rem;text-align:center;width:60px;height:60px;display:flex;align-items:center;justify-content:center;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="dashboard.php" class="nav-link d-inline"><i class="bi bi-house me-1"></i>Inicio</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h4 class="mb-1" style="font-family:'Playfair Display',serif;">📚 Catálogo de Libros</h4>
  <p class="text-muted mb-4">Explora todos los libros disponibles</p>

  <!-- Búsqueda -->
  <form method="GET" class="row g-2 mb-4">
    <div class="col-md-6">
      <input type="text" name="search" class="form-control" placeholder="🔍 Buscar por título o autor..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-md-3">
      <select name="genre" class="form-select">
        <option value="">Todos los géneros</option>
        <?php while ($g = $genres->fetch_assoc()): ?>
          <option value="<?= htmlspecialchars($g['genre']) ?>" <?= $genre === $g['genre'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($g['genre']) ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Buscar</button>
    </div>
    <?php if ($search || $genre): ?>
    <div class="col-md-1">
      <a href="catalog.php" class="btn btn-outline-secondary w-100"><i class="bi bi-x"></i></a>
    </div>
    <?php endif; ?>
  </form>

  <?php if ($books->num_rows === 0): ?>
    <div class="alert alert-info"><i class="bi bi-info-circle"></i> No se encontraron libros.</div>
  <?php endif; ?>

  <div class="row g-3">
    <?php while ($book = $books->fetch_assoc()): ?>
    <div class="col-md-6 col-lg-4">
      <div class="card shadow-sm p-3 h-100">
        <div class="d-flex gap-3 align-items-start">
          <div class="book-icon"><i class="bi bi-book"></i></div>
          <div class="flex-grow-1">
            <strong><?= htmlspecialchars($book['title']) ?></strong>
            <div class="text-muted small mt-1">
              <i class="bi bi-person"></i> <?= htmlspecialchars($book['author']) ?><br>
              <?php if ($book['year']): ?><i class="bi bi-calendar3"></i> <?= $book['year'] ?> &nbsp;<?php endif; ?>
              <?php if ($book['genre']): ?><span class="badge bg-light text-dark"><?= htmlspecialchars($book['genre']) ?></span><?php endif; ?>
            </div>
            <div class="mt-2">
              <span class="badge <?= $book['available'] > 0 ? 'bg-success' : 'bg-danger' ?>">
                <?= $book['available'] > 0 ? "✅ {$book['available']} disponibles" : "❌ No disponible" ?>
              </span>
            </div>
          </div>
        </div>
        <?php if ($role === 'Reader' && $book['available'] > 0): ?>
        <a href="request_book.php?id=<?= $book['id'] ?>" class="btn btn-sm btn-outline-primary mt-3">
          <i class="bi bi-hand-index"></i> Solicitar préstamo
        </a>
        <?php elseif ($role === 'Librarian' || $role === 'Administrator'): ?>
        <div class="mt-3 d-flex gap-2">
          <a href="manage_books.php?edit=<?= $book['id'] ?>" class="btn btn-sm btn-outline-warning">
            <i class="bi bi-pencil"></i> Editar
          </a>
          <a href="manage_books.php?delete=<?= $book['id'] ?>" class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este libro?')">
            <i class="bi bi-trash"></i>
          </a>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
