

CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30) NOT NULL
);

INSERT IGNORE INTO roles (id, name) VALUES 
  (1, 'Administrator'), 
  (2, 'Librarian'), 
  (3, 'Reader');

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role_id INT NOT NULL DEFAULT 3,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Usuario admin: admin@biblioteca.com / admin123
INSERT IGNORE INTO users (username, email, password, role_id) VALUES 
  ('Admin', 'admin@biblioteca.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(100) NOT NULL,
  year INT,
  genre VARCHAR(50),
  quantity INT NOT NULL DEFAULT 1,
  available INT NOT NULL DEFAULT 1
);

INSERT IGNORE INTO books (title, author, year, genre, quantity, available) VALUES
  ('Don Quijote de la Mancha', 'Miguel de Cervantes', 1605, 'Novela', 3, 3),
  ('Cien Años de Soledad', 'Gabriel García Márquez', 1967, 'Realismo mágico', 2, 2),
  ('Harry Potter y la Piedra Filosofal', 'J.K. Rowling', 1997, 'Fantasía', 5, 5);

CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  date_of_issue DATE NOT NULL,
  date_of_return DATE,
  returned TINYINT(1) DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (book_id) REFERENCES books(id)
);
