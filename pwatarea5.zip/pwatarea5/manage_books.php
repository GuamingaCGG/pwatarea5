<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();
if (getRole() !== 'Librarian' && getRole() !== 'Administrator') {
    header("Location: dashboard.php"); exit();
}

$msg = '';

// Eliminar libro
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM books WHERE id = $id");
    $msg = '<div class="alert alert-success">📕 Libro eliminado.</div>';
}

// Guardar (crear o editar)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = intval($_POST['id'] ?? 0);
    $title    = trim($_POST['title']);
    $author   = trim($_POST['author']);
    $year     = intval($_POST['year'] ?? 0);
    $genre    = trim($_POST['genre']);
    $quantity = intval($_POST['quantity']);

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE books SET title=?,author=?,year=?,genre=?,quantity=?,available=? WHERE id=?");
        $stmt->bind_param("ssissii", $title, $author, $year, $genre, $quantity, $quantity, $id);
        $stmt->execute();
        $msg = '<div class="alert alert-success">✅ Libro actualizado.</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO books (title,author,year,genre,quantity,available) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssissi", $title, $author, $year, $genre, $quantity, $quantity);
        $stmt->execute();
        $msg = '<div class="alert alert-success">✅ Libro agregado.</div>';
    }
}

// Cargar libro para editar
$editBook = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $r = $conn->query("SELECT * FROM books WHERE id = $id");
    $editBook = $r->fetch_assoc();
}

$books = $conn->query("SELECT * FROM books ORDER BY title");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestionar Libros</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
  h4{font-family:'Playfair Display',serif;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="dashboard.php" class="nav-link d-inline"><i class="bi bi-house me-1"></i>Inicio</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <?= $msg ?>
  <div class="row g-4">
    <!-- FORMULARIO -->
    <div class="col-md-4">
      <div class="card shadow-sm p-4">
        <h5><i class="bi bi-<?= $editBook ? 'pencil' : 'plus-circle' ?> me-2"></i><?= $editBook ? 'Editar Libro' : 'Agregar Libro' ?></h5>
        <form method="POST">
          <?php if ($editBook): ?>
            <input type="hidden" name="id" value="<?= $editBook['id'] ?>">
          <?php endif; ?>
          <div class="mb-3">
            <label class="form-label">Título *</label>
            <input type="text" name="title" class="form-control" required value="<?= htmlspecialchars($editBook['title'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Autor *</label>
            <input type="text" name="author" class="form-control" required value="<?= htmlspecialchars($editBook['author'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Año</label>
            <input type="number" name="year" class="form-control" min="1000" max="2100" value="<?= $editBook['year'] ?? '' ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Género</label>
            <input type="text" name="genre" class="form-control" placeholder="Ej: Novela, Fantasía..." value="<?= htmlspecialchars($editBook['genre'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Cantidad *</label>
            <input type="number" name="quantity" class="form-control" min="1" required value="<?= $editBook['quantity'] ?? 1 ?>">
          </div>
          <button type="submit" class="btn btn-primary w-100">
            <i class="bi bi-save"></i> <?= $editBook ? 'Actualizar' : 'Agregar Libro' ?>
          </button>
          <?php if ($editBook): ?>
          <a href="manage_books.php" class="btn btn-outline-secondary w-100 mt-2"><i class="bi bi-x"></i> Cancelar</a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <!-- LISTA -->
    <div class="col-md-8">
      <h4>📚 Todos los Libros</h4>
      <div class="card shadow-sm">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-dark">
              <tr><th>Título</th><th>Autor</th><th>Género</th><th>Stock</th><th>Disponibles</th><th>Acciones</th></tr>
            </thead>
            <tbody>
              <?php while ($b = $books->fetch_assoc()): ?>
              <tr>
                <td><strong><?= htmlspecialchars($b['title']) ?></strong></td>
                <td><?= htmlspecialchars($b['author']) ?></td>
                <td><?= htmlspecialchars($b['genre'] ?? '-') ?></td>
                <td><?= $b['quantity'] ?></td>
                <td>
                  <span class="badge <?= $b['available'] > 0 ? 'bg-success' : 'bg-danger' ?>">
                    <?= $b['available'] ?>
                  </span>
                </td>
                <td>
                  <a href="?edit=<?= $b['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                  <a href="?delete=<?= $b['id'] ?>" class="btn btn-sm btn-outline-danger ms-1"
                     onclick="return confirm('¿Eliminar «<?= htmlspecialchars(addslashes($b['title'])) ?>»?')">
                    <i class="bi bi-trash"></i>
                  </a>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
