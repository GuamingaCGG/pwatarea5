<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireRole('Administrator');

$msg = '';

// Cambiar rol
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $uid    = intval($_POST['user_id']);
    $roleId = intval($_POST['role_id']);
    if ($uid !== $_SESSION['user_id']) { // No puede cambiarse a sí mismo
        $stmt = $conn->prepare("UPDATE users SET role_id=? WHERE id=?");
        $stmt->bind_param("ii", $roleId, $uid);
        $stmt->execute();
        $msg = '<div class="alert alert-success">✅ Rol actualizado.</div>';
    } else {
        $msg = '<div class="alert alert-warning">⚠️ No puedes cambiar tu propio rol.</div>';
    }
}

// Eliminar usuario
if (isset($_GET['delete'])) {
    $uid = intval($_GET['delete']);
    if ($uid !== $_SESSION['user_id']) {
        $conn->query("DELETE FROM users WHERE id = $uid");
        $msg = '<div class="alert alert-success">🗑️ Usuario eliminado.</div>';
    }
}

$users = $conn->query("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id ORDER BY u.id");
$roles = $conn->query("SELECT * FROM roles");
$rolesArr = [];
while ($r = $roles->fetch_assoc()) $rolesArr[$r['id']] = $r['name'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestionar Usuarios</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
  h4{font-family:'Playfair Display',serif;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="dashboard.php" class="nav-link d-inline"><i class="bi bi-house me-1"></i>Inicio</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h4 class="mb-1">👥 Gestionar Usuarios</h4>
  <p class="text-muted mb-4">Administra los roles y permisos de los usuarios</p>
  <?= $msg ?>

  <div class="card shadow-sm">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
          <tr><th>#</th><th>Usuario</th><th>Correo</th><th>Rol Actual</th><th>Cambiar Rol</th><th>Eliminar</th></tr>
        </thead>
        <tbody>
          <?php while ($u = $users->fetch_assoc()): ?>
          <?php $isSelf = $u['id'] == $_SESSION['user_id']; ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td>
              <strong><?= htmlspecialchars($u['username']) ?></strong>
              <?php if ($isSelf): ?> <span class="badge bg-secondary">Tú</span><?php endif; ?>
            </td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td>
              <?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
                $colors = ['Administrator'=>'danger','Librarian'=>'warning text-dark','Reader'=>'success'];
                $c = $colors[$u['role_name']] ?? 'secondary';
                $names = ['Administrator'=>'Administrador','Librarian'=>'Bibliotecario','Reader'=>'Lector'];
              ?>
              <span class="badge bg-<?= $c ?>"><?= $names[$u['role_name']] ?? $u['role_name'] ?></span>
            </td>
            <td>
              <?php if (!$isSelf): ?>
              <form method="POST" class="d-flex gap-2">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <select name="role_id" class="form-select form-select-sm" style="width:140px;">
                  <?php foreach ($rolesArr as $rid => $rname): ?>
                    <option value="<?= $rid ?>" <?= $u['role_id'] == $rid ? 'selected' : '' ?>><?= $rname ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check"></i></button>
              </form>
              <?php else: ?>
                <span class="text-muted small">No editable</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if (!$isSelf): ?>
              <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger"
                 onclick="return confirm('¿Eliminar a <?= htmlspecialchars(addslashes($u['username'])) ?>?')">
                <i class="bi bi-trash"></i>
              </a>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
