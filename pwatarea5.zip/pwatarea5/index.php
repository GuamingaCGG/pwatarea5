<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';

if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT u.id, u.username, u.password, r.name as role FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Biblioteca Online - Iniciar Sesión</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    font-family: 'Lato', sans-serif;
  }
  .login-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 2.5rem;
    color: white;
  }
  h1 { font-family: 'Playfair Display', serif; color: #e8d5b0; }
  .form-control {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    border-radius: 8px;
  }
  .form-control:focus { background: rgba(255,255,255,0.15); color: white; border-color: #e8d5b0; box-shadow: none; }
  .form-control::placeholder { color: rgba(255,255,255,0.4); }
  .btn-login { background: #e8d5b0; color: #1a1a2e; font-weight: 700; border: none; border-radius: 8px; padding: 10px; }
  .btn-login:hover { background: #d4b896; color: #1a1a2e; }
  .hint { background: rgba(232,213,176,0.1); border-left: 3px solid #e8d5b0; padding: 10px 15px; border-radius: 4px; font-size: 0.85rem; }
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="login-card shadow-lg">
        <div class="text-center mb-4">
          <i class="bi bi-book-half" style="font-size:3rem; color:#e8d5b0;"></i>
          <h1 class="mt-2">Biblioteca Online</h1>
          <p class="text-white-50">Sistema de Gestión</p>
        </div>

        <?php if ($error): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>

        <form method="POST">
          <div class="mb-3">
            <label class="form-label text-white-75"><i class="bi bi-envelope"></i> Correo electrónico</label>
            <input type="email" name="email" class="form-control" placeholder="correo@ejemplo.com" required>
          </div>
          <div class="mb-4">
            <label class="form-label text-white-75"><i class="bi bi-lock"></i> Contraseña</label>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
          </div>
          <button type="submit" class="btn btn-login w-100 mb-3">
            <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión
          </button>
        </form>

        <p class="text-center mb-2">
          <a href="register.php" class="text-warning">¿No tienes cuenta? Regístrate</a>
        </p>

        <div class="hint mt-3 text-white-50">
          <strong class="text-warning">Cuenta de prueba:</strong><br>
          📧 admin@biblioteca.com<br>
          🔑 password
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
