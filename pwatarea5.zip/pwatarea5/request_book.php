<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

$bookId = intval($_GET['id'] ?? 0);
$userId = $_SESSION['user_id'];
$msg = '';

if (!$bookId) { header("Location: catalog.php"); exit(); }

$book = $conn->query("SELECT * FROM books WHERE id = $bookId")->fetch_assoc();
if (!$book) { header("Location: catalog.php"); exit(); }

if ($book['available'] <= 0) {
    $msg = '<div class="alert alert-danger">❌ Este libro no está disponible ahora.</div>';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $today = date('Y-m-d');
    $return = date('Y-m-d', strtotime('+14 days'));

    // Verificar que no tenga el mismo libro sin devolver
    $check = $conn->prepare("SELECT id FROM transactions WHERE user_id=? AND book_id=? AND returned=0");
    $check->bind_param("ii", $userId, $bookId);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $msg = '<div class="alert alert-warning">⚠️ Ya tienes este libro en préstamo.</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO transactions (user_id, book_id, date_of_issue, date_of_return) VALUES (?,?,?,?)");
        $stmt->bind_param("iiss", $userId, $bookId, $today, $return);
        $stmt->execute();

        $conn->query("UPDATE books SET available = available - 1 WHERE id = $bookId");
        $msg = '<div class="alert alert-success">✅ ¡Libro solicitado! Devolución esperada: <strong>' . $return . '</strong></div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Solicitar Libro</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body{background:#f8f5f0;font-family:'Lato',sans-serif;}
  .navbar{background:linear-gradient(90deg,#1a1a2e,#0f3460);}
  .navbar-brand{font-family:'Playfair Display',serif;color:#e8d5b0!important;}
  .nav-link{color:rgba(255,255,255,0.8)!important;}
  .card{border:none;border-radius:12px;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i class="bi bi-book-half me-2"></i>Biblioteca Online</a>
    <div class="ms-auto">
      <a href="catalog.php" class="nav-link d-inline"><i class="bi bi-journals me-1"></i>Catálogo</a>
      <a href="logout.php" class="btn btn-sm btn-outline-light ms-2"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </div>
  </div>
</nav>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm p-4">
        <div class="text-center mb-4">
          <div style="font-size:4rem;">📖</div>
          <h4 style="font-family:'Playfair Display',serif;"><?= htmlspecialchars($book['title']) ?></h4>
          <p class="text-muted"><?= htmlspecialchars($book['author']) ?> · <?= $book['year'] ?></p>
          <span class="badge bg-success">✅ <?= $book['available'] ?> disponibles</span>
        </div>

        <?= $msg ?>

        <?php if (empty($msg) || strpos($msg, 'warning') !== false): ?>
        <div class="alert alert-info">
          <i class="bi bi-info-circle"></i> El préstamo es por <strong>14 días</strong>. Fecha de devolución estimada: <strong><?= date('Y-m-d', strtotime('+14 days')) ?></strong>
        </div>
        <form method="POST">
          <button type="submit" class="btn btn-primary w-100 btn-lg">
            <i class="bi bi-hand-index me-2"></i>Confirmar Solicitud
          </button>
        </form>
        <?php endif; ?>

        <a href="catalog.php" class="btn btn-outline-secondary w-100 mt-3">
          <i class="bi bi-arrow-left me-1"></i>Volver al catálogo
        </a>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
